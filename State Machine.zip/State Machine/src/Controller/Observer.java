package Controller;

public abstract class Observer {
    protected GarageDoorSystem gds;
    public abstract void update();
}
